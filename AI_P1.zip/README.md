# 🧠 AI-Powered Personal Productivity Assistant

A fully functional AI assistant built with Python and Streamlit that uses Claude's tool-calling API to manage notes, to-dos, and reminders through natural language.

## ✨ Features

- 📝 **Smart Notes** — Take and retrieve notes via natural language
- ✅ **Todo Management** — Add, list, and complete tasks with priorities
- ⏰ **Reminders** — Set reminders with natural time expressions
- 🤖 **Multi-turn Chat** — Session memory across the conversation
- 🔧 **Tool-Calling Architecture** — Claude decides which tool to use automatically
- 💾 **Persistent Storage** — All data saved as JSON files

## 🚀 Live Demo

> Deployed on Streamlit Community Cloud  
> 👉 **[https://your-app.streamlit.app](https://your-app.streamlit.app)**

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend UI | Streamlit |
| LLM | Anthropic Claude (claude-opus-4-5) |
| Tool-Calling | Anthropic Python SDK |
| Storage | JSON files |
| Deployment | Streamlit Community Cloud |

## ⚙️ Setup

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/ai-productivity-assistant.git
cd ai-productivity-assistant
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set your API key
```bash
export ANTHROPIC_API_KEY=your_api_key_here
```

Or create a `.env` file:
```
ANTHROPIC_API_KEY=your_api_key_here
```

### 4. Run locally
```bash
streamlit run app.py
```

## 🌐 Deploy to Streamlit Cloud (Free)

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your GitHub repo
4. Add `ANTHROPIC_API_KEY` in **Secrets** settings
5. Click Deploy — get a free public URL instantly!

## 📁 Project Structure

```
ai-productivity-assistant/
├── app.py              # Streamlit UI + chat interface
├── llm.py              # Claude API + tool-calling loop
├── tools.py            # All productivity tool functions + definitions
├── requirements.txt    # Python dependencies
├── .streamlit/
│   └── secrets.toml    # API key (local only, never commit)
├── data/               # Auto-created JSON storage
│   ├── notes.json
│   ├── todos.json
│   └── reminders.json
└── README.md
```

## 💬 Example Prompts

- *"Take a note: Meeting with design team about new dashboard mockups"*
- *"Add a high priority todo: Review the quarterly report before Friday"*
- *"Set a reminder for tomorrow at 9am to send the weekly update email"*
- *"Summarize all my notes"*
- *"What are my pending tasks?"*
- *"Give me an overview of everything"*

## 🔧 Architecture

The app uses an **agentic tool-calling loop**:

```
User Input → Claude (decides which tool) → Tool Execution → Result → Claude (responds) → User
```

Claude automatically selects the right tool based on intent — no rigid command parsing needed.

## 📄 License

MIT License — free to use and modify.
