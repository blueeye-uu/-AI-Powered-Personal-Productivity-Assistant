"""
Productivity tools used by the AI assistant via tool-calling.
All data is stored in JSON files for persistence.
"""
import json
import os
from datetime import datetime

DATA_DIR = "data"
NOTES_FILE = os.path.join(DATA_DIR, "notes.json")
TODOS_FILE = os.path.join(DATA_DIR, "todos.json")
REMINDERS_FILE = os.path.join(DATA_DIR, "reminders.json")


def _ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


def _load(filepath):
    _ensure_data_dir()
    if not os.path.exists(filepath):
        return []
    with open(filepath, "r") as f:
        return json.load(f)


def _save(filepath, data):
    _ensure_data_dir()
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2)


# ─── NOTES ───────────────────────────────────────────────────────────────────

def create_note(title: str, content: str) -> str:
    """Create and save a new note."""
    notes = _load(NOTES_FILE)
    note = {
        "id": len(notes) + 1,
        "title": title,
        "content": content,
        "created": datetime.now().isoformat()
    }
    notes.append(note)
    _save(NOTES_FILE, notes)
    return f"✅ Note '{title}' saved successfully."


def get_notes() -> list:
    """Return all saved notes."""
    return _load(NOTES_FILE)


def summarize_notes() -> str:
    """Return a formatted summary of all notes."""
    notes = _load(NOTES_FILE)
    if not notes:
        return "No notes found."
    summary = f"📝 **You have {len(notes)} note(s):**\n\n"
    for n in notes:
        summary += f"**{n['id']}. {n['title']}** _(saved {n['created'][:10]})_\n{n['content']}\n\n"
    return summary.strip()


# ─── TODOS ────────────────────────────────────────────────────────────────────

def add_todo(task: str, priority: str = "medium") -> str:
    """Add a new todo item."""
    todos = _load(TODOS_FILE)
    todo = {
        "id": len(todos) + 1,
        "task": task,
        "priority": priority,
        "done": False,
        "created": datetime.now().isoformat()
    }
    todos.append(todo)
    _save(TODOS_FILE, todos)
    return f"✅ Todo added: '{task}' (priority: {priority})"


def get_todos() -> list:
    """Return all todo items."""
    return _load(TODOS_FILE)


def complete_todo(task_id: int) -> str:
    """Mark a todo as complete."""
    todos = _load(TODOS_FILE)
    for t in todos:
        if t["id"] == task_id:
            t["done"] = True
            _save(TODOS_FILE, todos)
            return f"✅ Task #{task_id} marked as complete!"
    return f"❌ Task #{task_id} not found."


def list_todos() -> str:
    """Return a formatted list of todos."""
    todos = _load(TODOS_FILE)
    if not todos:
        return "No todos yet!"
    result = f"✅ **You have {len(todos)} todo(s):**\n\n"
    for t in todos:
        status = "✅" if t["done"] else "⬜"
        priority_icon = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(t["priority"], "⬜")
        result += f"{status} {priority_icon} **{t['id']}.** {t['task']}\n"
    return result.strip()


# ─── REMINDERS ───────────────────────────────────────────────────────────────

def add_reminder(text: str, when: str) -> str:
    """Add a reminder with a time/date."""
    reminders = _load(REMINDERS_FILE)
    reminder = {
        "id": len(reminders) + 1,
        "text": text,
        "when": when,
        "created": datetime.now().isoformat()
    }
    reminders.append(reminder)
    _save(REMINDERS_FILE, reminders)
    return f"⏰ Reminder set: '{text}' for {when}"


def get_reminders() -> list:
    """Return all reminders."""
    return _load(REMINDERS_FILE)


def list_reminders() -> str:
    """Return formatted list of reminders."""
    reminders = _load(REMINDERS_FILE)
    if not reminders:
        return "No reminders set."
    result = f"⏰ **You have {len(reminders)} reminder(s):**\n\n"
    for r in reminders:
        result += f"🔔 **{r['id']}.** {r['text']} — _{r['when']}_\n"
    return result.strip()


# ─── OVERVIEW ────────────────────────────────────────────────────────────────

def get_all_context() -> str:
    """Return a complete overview of all notes, todos, and reminders."""
    notes = _load(NOTES_FILE)
    todos = _load(TODOS_FILE)
    reminders = _load(REMINDERS_FILE)

    pending = [t for t in todos if not t["done"]]
    done = [t for t in todos if t["done"]]

    ctx = f"""📊 **Productivity Overview** — {datetime.now().strftime('%B %d, %Y')}

📝 **Notes:** {len(notes)} total
✅ **Todos:** {len(pending)} pending, {len(done)} completed
⏰ **Reminders:** {len(reminders)} set
"""
    return ctx.strip()


# ─── TOOL DEFINITIONS FOR LLM ────────────────────────────────────────────────

TOOLS = [
    {
        "name": "create_note",
        "description": "Save a note with a title and content. Use when user wants to take a note, write something down, or save information.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Short title for the note"},
                "content": {"type": "string", "description": "Full content of the note"}
            },
            "required": ["title", "content"]
        }
    },
    {
        "name": "summarize_notes",
        "description": "Return a summary of all saved notes. Use when the user asks to see, read, or summarize their notes.",
        "input_schema": {"type": "object", "properties": {}}
    },
    {
        "name": "add_todo",
        "description": "Add a task to the to-do list. Use when user wants to add a task, reminder, or action item.",
        "input_schema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "The task description"},
                "priority": {"type": "string", "enum": ["low", "medium", "high"], "description": "Priority level"}
            },
            "required": ["task"]
        }
    },
    {
        "name": "list_todos",
        "description": "Show all todo items. Use when user asks to see their tasks or to-do list.",
        "input_schema": {"type": "object", "properties": {}}
    },
    {
        "name": "complete_todo",
        "description": "Mark a todo item as complete by its ID.",
        "input_schema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer", "description": "The ID number of the task to complete"}
            },
            "required": ["task_id"]
        }
    },
    {
        "name": "add_reminder",
        "description": "Set a reminder with a message and time. Use when user wants to be reminded about something.",
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "What to be reminded about"},
                "when": {"type": "string", "description": "When the reminder is for (e.g. 'tomorrow 9am', 'Friday')"}
            },
            "required": ["text", "when"]
        }
    },
    {
        "name": "list_reminders",
        "description": "Show all reminders. Use when the user asks to see their reminders.",
        "input_schema": {"type": "object", "properties": {}}
    },
    {
        "name": "get_all_context",
        "description": "Give a full overview of everything: notes count, todos, reminders. Use for general overviews.",
        "input_schema": {"type": "object", "properties": {}}
    }
]

TOOL_FUNCTIONS = {
    "create_note": lambda args: create_note(**args),
    "summarize_notes": lambda args: summarize_notes(),
    "add_todo": lambda args: add_todo(**args),
    "list_todos": lambda args: list_todos(),
    "complete_todo": lambda args: complete_todo(**args),
    "add_reminder": lambda args: add_reminder(**args),
    "list_reminders": lambda args: list_reminders(),
    "get_all_context": lambda args: get_all_context(),
}
