import streamlit as st
import json
from datetime import datetime
from tools import (
    create_note, get_notes, summarize_notes,
    add_todo, get_todos, complete_todo,
    add_reminder, get_reminders,
    get_all_context
)
from llm import chat_with_tools

st.set_page_config(
    page_title="AI Productivity Assistant",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Space Grotesk', sans-serif;
}

.main { background-color: #0f0f1a; color: #e2e8f0; }
.stApp { background-color: #0f0f1a; }

.chat-message {
    padding: 1rem 1.5rem;
    border-radius: 12px;
    margin: 0.5rem 0;
    max-width: 85%;
}
.user-message {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    margin-left: auto;
    text-align: right;
}
.assistant-message {
    background: #1e1e2e;
    border: 1px solid #2d2d3f;
    color: #e2e8f0;
}

.sidebar-card {
    background: #1e1e2e;
    border: 1px solid #2d2d3f;
    border-radius: 10px;
    padding: 12px 16px;
    margin: 6px 0;
    font-size: 0.85rem;
}
.sidebar-card.done { opacity: 0.5; text-decoration: line-through; }

.tool-badge {
    display: inline-block;
    background: #2d2d3f;
    color: #a78bfa;
    border-radius: 6px;
    padding: 2px 8px;
    font-size: 0.75rem;
    margin: 2px;
}

h1, h2, h3 { color: #a78bfa !important; }

.stButton > button {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 8px;
    font-family: 'Space Grotesk', sans-serif;
}
</style>
""", unsafe_allow_html=True)

# Session state
if "messages" not in st.session_state:
    st.session_state.messages = []
if "tool_log" not in st.session_state:
    st.session_state.tool_log = []

# --- Sidebar ---
with st.sidebar:
    st.markdown("## 🧠 AI Productivity")
    st.markdown("---")

    tab1, tab2, tab3 = st.tabs(["📝 Notes", "✅ Todos", "⏰ Reminders"])

    with tab1:
        notes = get_notes()
        if notes:
            for n in notes[-5:]:
                st.markdown(f'<div class="sidebar-card"><b>{n["title"]}</b><br><small>{n["created"][:10]}</small></div>', unsafe_allow_html=True)
        else:
            st.caption("No notes yet. Ask me to take a note!")

    with tab2:
        todos = get_todos()
        if todos:
            for t in todos[-5:]:
                cls = "sidebar-card done" if t["done"] else "sidebar-card"
                icon = "✅" if t["done"] else "⬜"
                st.markdown(f'<div class="{cls}">{icon} {t["task"]}</div>', unsafe_allow_html=True)
        else:
            st.caption("No todos yet. Ask me to add tasks!")

    with tab3:
        reminders = get_reminders()
        if reminders:
            for r in reminders[-5:]:
                st.markdown(f'<div class="sidebar-card">🔔 {r["text"]}<br><small>{r["when"]}</small></div>', unsafe_allow_html=True)
        else:
            st.caption("No reminders yet. Ask me to set one!")

    st.markdown("---")
    st.markdown("### 🛠️ Tool Activity")
    for log in st.session_state.tool_log[-8:]:
        st.markdown(f'<span class="tool-badge">{log}</span>', unsafe_allow_html=True)

    if st.button("🗑️ Clear Chat"):
        st.session_state.messages = []
        st.session_state.tool_log = []
        st.rerun()

# --- Main Chat ---
st.markdown("# 🧠 AI Productivity Assistant")
st.markdown("*Your intelligent companion for notes, todos, and reminders*")
st.markdown("---")

# Example prompts
if not st.session_state.messages:
    st.markdown("### 💡 Try asking me:")
    cols = st.columns(3)
    examples = [
        ("📝 Take a note", "Take a note: Meeting with team at 3pm about Q2 roadmap"),
        ("✅ Add a todo", "Add to my todo list: Review pull requests and update documentation"),
        ("⏰ Set reminder", "Set a reminder for tomorrow morning to call the dentist"),
        ("📋 Show summary", "Summarize all my notes"),
        ("📊 Show todos", "What are my pending todos?"),
        ("🔍 All context", "Give me a full overview of everything I have")
    ]
    for i, (label, prompt) in enumerate(examples):
        with cols[i % 3]:
            if st.button(label, key=f"ex_{i}"):
                st.session_state.messages.append({"role": "user", "content": prompt})
                st.rerun()

# Display messages
for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.markdown(f'<div class="chat-message user-message">👤 {msg["content"]}</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="chat-message assistant-message">🤖 {msg["content"]}</div>', unsafe_allow_html=True)

# Input
st.markdown("---")
user_input = st.chat_input("Ask me to take notes, manage todos, set reminders...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})

    with st.spinner("Thinking..."):
        response, tools_used = chat_with_tools(st.session_state.messages)

    st.session_state.messages.append({"role": "assistant", "content": response})
    st.session_state.tool_log.extend(tools_used)

    st.rerun()
