"""
LLM integration using Anthropic API with tool-calling architecture.
"""
import os
import anthropic
from tools import TOOLS, TOOL_FUNCTIONS

# Support both environment variable and Streamlit secrets
def _get_api_key():
    try:
        import streamlit as st
        return st.secrets.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_API_KEY")
    except Exception:
        return os.environ.get("ANTHROPIC_API_KEY")

client = anthropic.Anthropic(api_key=_get_api_key())

SYSTEM_PROMPT = """You are an intelligent, friendly AI Productivity Assistant. 
Your job is to help users manage their notes, to-do lists, and reminders efficiently.

When the user asks you to:
- Take a note / write something down → use create_note
- See/read/summarize notes → use summarize_notes
- Add a task / to-do → use add_todo  
- See tasks / to-do list → use list_todos
- Complete / finish a task → use complete_todo
- Set a reminder → use add_reminder
- See reminders → use list_reminders
- Overview / summary of everything → use get_all_context

Always use tools to actually perform actions. Confirm what you did clearly.
Be concise, helpful, and encouraging. Use emojis tastefully.
Today's date is: """ + __import__('datetime').datetime.now().strftime('%B %d, %Y')


def chat_with_tools(messages: list) -> tuple[str, list]:
    """
    Send messages to Claude with tool-calling support.
    Returns (response_text, list_of_tools_used).
    """
    tools_used = []

    # Convert session messages to API format
    api_messages = []
    for m in messages:
        api_messages.append({"role": m["role"], "content": m["content"]})

    # Agentic loop: keep calling until no more tool use
    while True:
        response = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=api_messages
        )

        # If no tool use, we're done
        if response.stop_reason == "end_turn":
            text = ""
            for block in response.content:
                if hasattr(block, "text"):
                    text += block.text
            return text, tools_used

        # Handle tool use
        if response.stop_reason == "tool_use":
            # Add assistant response to history
            api_messages.append({
                "role": "assistant",
                "content": response.content
            })

            # Process each tool call
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    tool_name = block.name
                    tool_input = block.input
                    tools_used.append(f"🔧 {tool_name}")

                    # Execute the tool
                    if tool_name in TOOL_FUNCTIONS:
                        result = TOOL_FUNCTIONS[tool_name](tool_input)
                    else:
                        result = f"Unknown tool: {tool_name}"

                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": result
                    })

            # Add tool results to history
            api_messages.append({
                "role": "user",
                "content": tool_results
            })

        else:
            # Unexpected stop reason
            break

    return "I encountered an issue. Please try again.", tools_used
